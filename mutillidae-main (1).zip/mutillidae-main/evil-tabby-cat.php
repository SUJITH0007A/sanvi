<script>
	parent.window.opener.location="https://www.duckduckgo.com";
</script>
So mean
