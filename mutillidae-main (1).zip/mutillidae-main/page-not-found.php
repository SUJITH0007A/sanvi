<div class="page-title">Page Not Found</div>

<?php include_once (__SITE_ROOT__.'/includes/back-button.inc');?>

<table>
	<tr id="id-bad-page-tr">
		<td colspan="2" class="error-message">
			Validation Error: 404 - Page Not Found
		</td>
	</tr>
</table>