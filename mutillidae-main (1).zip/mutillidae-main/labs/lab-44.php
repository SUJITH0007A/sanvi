<?php
$lLabNumber = 44;
$lTitle = "Lab 44: Error Handling - Grabbing Server Banners";
$lQuestion = "What is the difference between the HTTP HEAD method and the HTTP GET method?";
$lChoice_1 = "They are identical";
$lChoice_2 = "The HEAD method allows data to be posted to the server in the body of the HTTP request";
$lChoice_3 = "The HEAD method causes the server to send only HTTP response headers. The body is not sent.";
$lChoice_4 = "The GET method only works over HTTPS";
$lChoice_5 = "The HEAD method updates a specific section of a web page";
$lCorrectAnswer = 3;

require_once("labs/lab-template.inc");
?>