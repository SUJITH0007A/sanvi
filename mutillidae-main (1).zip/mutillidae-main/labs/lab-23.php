<?php
    $lLabNumber = 23;
    $lTitle = "Lab 23: Open Redirects - Part 1";
    $lQuestion = "The credits.php has a specific instance of an open redirect vulnerability. In this case, the redirect occurs because of the following";
    $lChoice_1 = "Calling the PHP header function to create a Location response header";
    $lChoice_2 = "Creating an HTML meta element with the equiv attribute";
    $lChoice_3 = "Calling the ASP.NET redirect function";
    $lChoice_4 = "Calling the Java redirect function";
    $lChoice_5 = "Calling the ASP Classic redirect function";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>