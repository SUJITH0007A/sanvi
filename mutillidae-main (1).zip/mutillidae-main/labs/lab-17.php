<?php
    $lLabNumber = 17;
    $lTitle = "Lab 17: LDAP Injection - Extract User Accounts";
    $lQuestion = "Perform LDAP injection to dump the contents of the directory. Which of these user accounts appears?";
    $lChoice_1 = "ferdinand";
    $lChoice_2 = "phinius";
    $lChoice_3 = "yasmine";
    $lChoice_4 = "robin";
    $lChoice_5 = "mike";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>