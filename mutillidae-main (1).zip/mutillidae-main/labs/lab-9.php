    <?php
    $lLabNumber = 9;
    $lTitle = "Lab 9: SQL Injection - Finding Number of Columns";
    $lQuestion = "Using the User Info page in Mutillidae, determine how many columns the accounts table contain?";
    $lChoice_1 = "1";
    $lChoice_2 = "3";
    $lChoice_3 = "5";
    $lChoice_4 = "7";
    $lChoice_5 = "9";
    $lCorrectAnswer = 4;

    require_once("labs/lab-template.inc");
?>