<?php
$lLabNumber = 56;
$lTitle = "Lab 56: JSON Web Token (JWT) Security - JSON Web Token (JWT) Session Timeout";
$lQuestion = "Using the Current User Information page, how long is the session timeout for the JSON Web Token (JWT)";
$lChoice_1 = "1 minutes";
$lChoice_2 = "10 minutes";
$lChoice_3 = "20 minutes";
$lChoice_4 = "30 minutes";
$lChoice_5 = "60 minutes";
$lCorrectAnswer = 4;

require_once("labs/lab-template.inc");
?>
