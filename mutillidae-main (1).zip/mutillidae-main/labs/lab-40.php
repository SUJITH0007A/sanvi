<?php
$lLabNumber = 40;
$lTitle = "Lab 40: Password Management - Intercepting Clear-Text Credentials";
$lQuestion = "Complete the lab to intercept credentials of the login page. Where is the username and password found within the HTTP packet?";
$lChoice_1 = "Request Header";
$lChoice_2 = "Request Body";
$lChoice_3 = "Response Header";
$lChoice_4 = "Response Body";
$lChoice_5 = "The username and password are not found in the HTTP packet";
$lCorrectAnswer = 2;

require_once("labs/lab-template.inc");
?>




