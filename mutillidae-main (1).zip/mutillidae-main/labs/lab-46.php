<?php
$lLabNumber = 46;
$lTitle = "Lab 46: Error Handling - Scanning with Nikto";
$lQuestion = "Which of these vulnerabilities does Nikto find in Mutillidae?";
$lChoice_1 = "SQL injection";
$lChoice_2 = "Cookie PHPSESSID created without the httponly flag";
$lChoice_3 = "Open redirect";
$lChoice_4 = "Parameter pollution";
$lChoice_5 = "Nikto does not find any vulnerabilities";
$lCorrectAnswer = 2;

require_once("labs/lab-template.inc");
?>