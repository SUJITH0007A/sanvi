<?php
    $lLabNumber = 11;
    $lTitle = "Lab 11: SQL Injection - SQLMap";
    $lQuestion = "Using the User Info page, according to SQLMap's --banner command, what back-end DBMS is Mutillidae II using?";
    $lChoice_1 = "PostGres version 3.0.1";
    $lChoice_2 = "MySQL Server / MariaDB";
    $lChoice_3 = "SQL Server";
    $lChoice_4 = "SQLite3";
    $lChoice_5 = "NoSQL";
    $lCorrectAnswer = 2;

    require_once("labs/lab-template.inc");
?>