<?php
$lLabNumber = 52;
$lTitle = "Lab 52: Server Configuration - Scanning with SSLScan";
$lQuestion = "Who issued the certificate for mutillidae.localhost?";
$lChoice_1 = "Go Daddy";
$lChoice_2 = "Verizon";
$lChoice_3 = "Smith";
$lChoice_4 = "mutillidae.localhost";
$lChoice_5 = "Section 7";
$lCorrectAnswer = 4;

require_once("labs/lab-template.inc");
?>
