<?php
$lLabNumber = 51;
$lTitle = "Lab 51: Server Configuration - Scanning with Nikto";
$lQuestion = "What is the URL of the of the PHPInfo() page?";
$lChoice_1 = "http://mutillidae.localhost/php-info.php";
$lChoice_2 = "http://mutillidae.localhost/php.html";
$lChoice_3 = "http://mutillidae.localhost/phpinfo.php";
$lChoice_4 = "http://mutillidae.localhost/index.php";
$lChoice_5 = "http://mutillidae.localhost/egg.php";
$lCorrectAnswer = 3;

require_once("labs/lab-template.inc");
?>
