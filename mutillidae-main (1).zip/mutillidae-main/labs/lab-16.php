<?php
    $lLabNumber = 16;
    $lTitle = "Lab 16: Command injection - Web Shell with Command injection";
    $lQuestion = "Once the web shell is working, use the web shell to run the uname command. What is the output of the uname command?";
    $lChoice_1 = "Berkley System Distribution (BSD)";
    $lChoice_2 = "root";
    $lChoice_3 = "linux";
    $lChoice_4 = "Apache";
    $lChoice_5 = "www-data";
    $lCorrectAnswer = 3;

    require_once("labs/lab-template.inc");
?>