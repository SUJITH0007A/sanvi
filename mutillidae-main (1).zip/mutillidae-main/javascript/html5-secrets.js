window.sessionStorage.setItem("Secure.IsUserLoggedIn?", "No");
window.sessionStorage.setItem("Secure.AuthenticationToken", "DU837HHFYTEYUE9S1934");
window.localStorage.setItem("Secure.CurrentStateofHTML5Storage","Completely Insecure");