$(function() {
	$(document).ready(function () {
		$('a.colorbox').colorbox({width:'700px',opacity:'0.60'});
	});
});
